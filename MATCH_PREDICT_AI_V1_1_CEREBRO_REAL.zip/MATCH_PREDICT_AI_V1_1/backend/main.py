import os, math, statistics
from datetime import datetime, timezone
from typing import Optional
import httpx
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

app = FastAPI(title="MATCH PREDICT AI", version="1.1")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

API_KEY = os.getenv("API_FOOTBALL_KEY", "")
BASE = "https://v3.football.api-sports.io"

class PredictRequest(BaseModel):
    home_team: str
    away_team: str
    league_id: Optional[int] = None
    season: Optional[int] = None

async def af_get(path, params):
    if not API_KEY:
        raise HTTPException(503, "API_FOOTBALL_KEY no configurada")
    async with httpx.AsyncClient(timeout=15) as c:
        r = await c.get(BASE + path, params=params, headers={"x-apisports-key": API_KEY})
        r.raise_for_status()
        data = r.json()
        if data.get("errors"):
            raise HTTPException(502, str(data["errors"]))
        return data.get("response", [])

async def team_search(name):
    return await af_get("/teams", {"search": name})

def poisson(k, lam):
    return math.exp(-lam) * lam**k / math.factorial(k)

def normalize(vals):
    s=sum(vals)
    return [v/s for v in vals] if s else [1/3]*len(vals)

def poisson_1x2(xg_h, xg_a):
    home=draw=away=0
    for h in range(0,8):
        for a in range(0,8):
            p=poisson(h,xg_h)*poisson(a,xg_a)
            if h>a: home+=p
            elif h==a: draw+=p
            else: away+=p
    return normalize([home,draw,away])

@app.get("/health")
async def health():
    return {"ok": True, "api_configured": bool(API_KEY), "utc": datetime.now(timezone.utc).isoformat()}

@app.post("/api/predict")
async def predict(req: PredictRequest):
    hs=await team_search(req.home_team)
    aws=await team_search(req.away_team)
    if not hs or not aws:
        raise HTTPException(404, "No se ha encontrado uno de los equipos en la fuente de datos.")

    home=hs[0]["team"]; away=aws[0]["team"]

    # V1.1: buscamos partidos recientes terminados. La capa de features
    # está preparada para incorporar estadísticas de partido cuando estén disponibles.
    hmatches=await af_get("/fixtures", {"team": home["id"], "last": 10})
    amatches=await af_get("/fixtures", {"team": away["id"], "last": 10})

    def form(matches, team_id):
        gf=[]; ga=[]
        for m in matches:
            f=m.get("fixture",{})
            if f.get("status",{}).get("short") not in ("FT","AET","PEN"): continue
            teams=m.get("teams",{})
            goals=m.get("goals",{})
            if teams.get("home",{}).get("id")==team_id:
                gf.append(goals.get("home") or 0); ga.append(goals.get("away") or 0)
            else:
                gf.append(goals.get("away") or 0); ga.append(goals.get("home") or 0)
        return (statistics.mean(gf) if gf else 1.25,
                statistics.mean(ga) if ga else 1.10,
                len(gf))

    hgf,hga,hn=form(hmatches,home["id"])
    agf,aga,an=form(amatches,away["id"])

    # Blend simple attack/defence estimates. This is intentionally a baseline,
    # not presented as a learned model until enough historical data is collected.
    xg_h=max(.25, min(4.0, (hgf + aga)*0.55 + .25))
    xg_a=max(.20, min(3.5, (agf + hga)*0.45))
    probs=poisson_1x2(xg_h,xg_a)

    best=(0,0,0)
    for h in range(0,6):
        for a in range(0,6):
            p=poisson(h,xg_h)*poisson(a,xg_a)
            if p>best[2]: best=(h,a,p)

    data_quality=min(1, (hn+an)/20)
    confidence=round(5 + 4*data_quality*max(probs),1)

    factors=[
        f"{hn} partidos recientes utilizables de {home['name']}.",
        f"{an} partidos recientes utilizables de {away['name']}.",
        f"Promedio goles a favor: {hgf:.2f} / {agf:.2f}.",
        f"Promedio goles recibidos: {hga:.2f} / {aga:.2f}.",
        "Modelo base: distribución de Poisson; se sustituirá progresivamente por un ensemble calibrado."
    ]

    return {
        "source":"API-Football",
        "updated_at":datetime.now(timezone.utc).isoformat(),
        "home":home["name"], "away":away["name"],
        "probabilities":{"home":round(probs[0]*100,1),"draw":round(probs[1]*100,1),"away":round(probs[2]*100,1)},
        "expected_goals":{"home":round(xg_h,2),"away":round(xg_a,2)},
        "predicted_score":f"{best[0]}-{best[1]}",
        "confidence":confidence,
        "data_quality":round(data_quality*100),
        "factors":factors
    }
