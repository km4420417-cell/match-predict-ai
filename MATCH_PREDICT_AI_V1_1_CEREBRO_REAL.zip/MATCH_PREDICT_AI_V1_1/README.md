# MATCH PREDICT AI V1.1 — CEREBRO

## Qué cambia
Esta versión sustituye el generador aleatorio por una API backend que consulta datos de API-Football y calcula una primera predicción estadística basada en partidos recientes.

## Arquitectura
Frontend (Netlify) -> FastAPI -> API-Football -> features -> Poisson -> probabilidades.

## Activación
1. Crea una cuenta en API-Football.
2. Obtén tu API key.
3. En el backend configura `API_FOOTBALL_KEY`.
4. Instala dependencias: `pip install -r backend/requirements.txt`
5. Ejecuta: `uvicorn backend.main:app --host 0.0.0.0 --port 8000`
6. Cambia `API` en frontend/app.js por la URL pública del backend.

## Próxima evolución
- base PostgreSQL de históricos
- Elo/MP Rating
- Dixon-Coles
- xG y estadísticas avanzadas
- lesiones y sanciones
- alineaciones
- cuotas como señal secundaria
- Monte Carlo
- calibración Brier/Log Loss
- backtesting temporal sin leakage
- versionado del modelo

Nunca se deben inventar datos faltantes.
