const API="http://localhost:8000";
async function go(){
 const h=document.getElementById("home").value.trim(),a=document.getElementById("away").value.trim();
 const msg=document.getElementById("msg"); msg.textContent="Analizando datos reales…";
 try{
  const r=await fetch(API+"/api/predict",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({home_team:h,away_team:a})});
  const d=await r.json(); if(!r.ok) throw new Error(d.detail||"Error");
  document.getElementById("out").className="";
  document.getElementById("out").innerHTML=`<div class="title">${d.home} <span>VS</span> ${d.away}</div>
  <div class="cards">
  <div class="card"><small>LOCAL</small><b>${d.probabilities.home}%</b><div class="bar" style="width:${d.probabilities.home}%"></div></div>
  <div class="card"><small>EMPATE</small><b>${d.probabilities.draw}%</b><div class="bar" style="width:${d.probabilities.draw}%"></div></div>
  <div class="card"><small>VISITANTE</small><b>${d.probabilities.away}%</b><div class="bar" style="width:${d.probabilities.away}%"></div></div></div>
  <div class="grid"><div class="panel"><small>MARCADOR MÁS PROBABLE</small><div class="score">${d.predicted_score}</div><p>Goles esperados: ${d.expected_goals.home} — ${d.expected_goals.away}</p></div>
  <div class="panel"><small>CONFIANZA</small><div class="score">${d.confidence}/10</div><p>Calidad de datos: ${d.data_quality}%</p></div></div>
  <div class="panel factors"><small>FACTORES REALES USADOS</small><ul>${d.factors.map(x=>`<li>${x}</li>`).join("")}</ul><small>Fuente: ${d.source}</small></div>`;
  msg.textContent="Datos actualizados: "+new Date(d.updated_at).toLocaleString();
 }catch(e){msg.textContent="No se pudo conectar con el motor: "+e.message+" (el frontend está listo; falta desplegar el backend y configurar la API)."}
}